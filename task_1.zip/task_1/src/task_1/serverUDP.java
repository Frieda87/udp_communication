package task_1;
import java.io. * ;
import java.net. * ;
import java.util.ArrayList;


public class serverUDP {
    /**
     The server side that listens for datagrams of the port provided
     through the command line.

     ! Server needs to be started first, port specified need to be used
     on client side as well !

     If server does not receive the expected packets (range of current
     sequence number (currentSN) plus slidingWindow size), it will report
     a transmission failure and prompt the sending of the last window.
     */
    static int currentSN = 1;
    static public final int slidingWindow = 5;
    static int port = 0;
    static DatagramSocket dgramSocket;


    public static void main(String[] args) throws IOException {
        // check existence of required args
        if (args.length == 0) {
            System.out.println("Please provide -port client will send packets to!");
            System.exit(1);
        }
        // extract port value
        if (args[0].equals("-port") || args[0].equals("-p")) {
            port = Integer.parseInt(args[1]);
            // make sure port is in available port range
            if ((port <= 1024) || (port >= 65535)) {
                System.out.println(("Specify port in range 1024 <= port <= 65535"));
                System.exit(1);
            }
        } else {
            System.out.println(("Specify -port in range 1024 <= port <= 65535"));
            System.exit(1);
        }

        // initialize new socket on specified port
        dgramSocket = new DatagramSocket(port);
        System.out.println(String.format("SERVER started listening on port %d", port));
        while (currentSN < 60) {
            // use PrepareServerResponse for server response to client
            PrepareServerResponse prepareResponse = serverUDP.receiveMessage();
            String msgOut;
            // report successful transmission in case all packets received
            // report failure and ask for retransmission in case of missing packets
            if (prepareResponse.success) {
                msgOut = "SUCCESS";
            } else {
                msgOut = "FAILURE";
            }
            serverUDP.responseToClient(msgOut, prepareResponse.cliAddress, prepareResponse.cliPort);
        }
        // close socket after transmission completed
        System.out.println("SERVER transmission completed. Socket will be closed.");
        dgramSocket.close();
    }

    private static void responseToClient(String msgOut, InetAddress cliAddress, int cliPort) throws IOException {
        DatagramPacket outgoingPacket = new DatagramPacket(msgOut.getBytes(), msgOut.length(), cliAddress, cliPort);
        dgramSocket.send(outgoingPacket);
    }

    private static PrepareServerResponse receiveMessage() throws IOException {
        String msgIn;
        DatagramPacket incomingPacket;
        ArrayList<Integer> receivedPackets;
        ArrayList<Integer> expectedPackets;
        // create buffer for expected packets
        byte[] buffer = new byte[512];

        incomingPacket = new DatagramPacket(buffer, buffer.length);
        receivedPackets = new ArrayList<>();
        // receive amount of packets as indicated by slidingWindow
        while (receivedPackets.size() < slidingWindow) {
            dgramSocket.receive(incomingPacket);
            msgIn = new String(incomingPacket.getData(), 0, incomingPacket.getLength());
            // extract sequence number (SN) from packet payload
            int newSN = getSN(msgIn);
            // add SN to a check list
            receivedPackets.add(newSN);
        }
        // create a list of expected SNs
        expectedPackets = new ArrayList<>();
        for (int i = currentSN; i < currentSN+slidingWindow; i++) {
            expectedPackets.add(i);
        }
        // check whether expected and received packets match
        boolean success =  getSuccessStatus(receivedPackets, expectedPackets);
        InetAddress cliAddress = incomingPacket.getAddress();
        int cliPort = incomingPacket.getPort();
        // send response to client depending on transmission status
        if (success) {
            // if successful, increase currentSN by window size
            currentSN += slidingWindow;
        }
        return new PrepareServerResponse(cliAddress, cliPort, success);
        }

    private static boolean getSuccessStatus(ArrayList<Integer> rcdPackets, ArrayList<Integer> expectedPackets) {
        return rcdPackets.containsAll(expectedPackets);
    }

    private static int getSN(String msgIn) {
        msgIn = msgIn.replace("{", "").replace("}", "");
        String[] messageString = msgIn.split(", ");
        String[] newStringSN = messageString[1].split("=");
        int newSN = Integer.parseInt(newStringSN[1]);
        System.out.println(String.format("Message with SN %d received.", newSN));
        return newSN;
    }
}
