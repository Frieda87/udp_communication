package task_1;


import java.io. * ;
import java.net. * ;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

public class clientUDP {
    /**
     The client side that takes a port and a host as command line
     arguments and handles exception accordingly.

     ! It needs to be started after the server and needs the same port
     as specified by server !

     The initial sequence number (SN) is set to 1. The payload consisting
     of the data ("umbrella") and the SN are stored in a hashtable. The sliding
     window is set to 5.
     */
    private static int SN = 1;
    public static int port = 0;
    private static InetAddress host = null;
    private static Hashtable<String, String> msgDict = new Hashtable<String, String>();
    final static int slidingWindow = 5;

    public static void main(String[] args) throws IOException, InterruptedException {
        // check existence of required args
        if (args.length == 0) {
            System.out.println("Please provide -port and -host!");
            System.exit(1);
        }
        // extract values from args, make sure port is in available port range
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-port") || args[i].equals("-p")) {
                i++;
                port = Integer.parseInt(args[i]);
                if ((port <= 1024) || (port >= 65535)) {
                    System.out.println(("Specify port in range 1024 <= port <= 65535"));
                    System.exit(1);
                }
            } else if (args[i].equals("-host") || args[i].equals("-h")) {
                i++;
                if (!args[i].contains("local")) {
                    System.out.println("Host not found- only localhost possible!");
                    System.exit(1);
                };
                host = InetAddress.getLocalHost();
            }
        }
        System.out.println(String.format("Specified port: %d", port));
        System.out.println(String.format("Specified host: %s", host));
        System.out.println("CLIENT will start sending.");
        // initialize DatagramSocket and provide port and host to createClient() method
        DatagramSocket dgramSocket = new DatagramSocket();
        while (SN < 60) {
            clientUDP.createClient(port, host, dgramSocket);
            TimeUnit.SECONDS.sleep(3);
        }
        // close socket after transmission completed
        System.out.println("CLIENT transmission completed. Socket will be closed.");
        dgramSocket.close();
    }

    public static void createClient(int port, InetAddress host, DatagramSocket dgramSocket) throws IOException {
        // keeping in slidingWindow range with aid of counter
        int counter = 0;
        while (counter < slidingWindow) {
            // payload added to hashtable
            msgDict.put("message", "umbrella");
            msgDict.put("SN", String.format("%d", SN));
            // hashtable turned into String for sending
            String msgDictString = msgDict.toString();
            byte[] bufferDict = msgDictString.getBytes();

            // create datagram and send to specified server socket
            DatagramPacket outgoingPacket = new DatagramPacket(bufferDict, bufferDict.length, host, port);
            dgramSocket.send(outgoingPacket);
            System.out.println(String.format("Packet with SN %d sent", SN));
            // increase SN and counter to proceed with next package within window range
            SN++;
            counter++;
        }
        // if one window sent, a response from server is expected
        // create buffer for incoming packet and receive it
        byte[] buffer = new byte[256];

        DatagramPacket incomingPacket = new DatagramPacket(buffer, buffer.length);
        dgramSocket.receive(incomingPacket);
        String incomingMessage = new String(incomingPacket.getData(), 0, incomingPacket.getLength());
        System.out.println("SERVER responded with: " + incomingMessage);
        // if server reports success, next packets in window size are sent
        // if server reports failure, last window is sent again
        if (incomingMessage.contains("SUCCESS")) {
            System.out.println("TRANSMISSION SUCCESS");
        } else {
            System.out.println("TRANSMISSION FAILURE");
            SN -= (slidingWindow - 1);
        }
    }
}
