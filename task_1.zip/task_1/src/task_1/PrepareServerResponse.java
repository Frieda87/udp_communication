package task_1;

import java.net.InetAddress;

final class PrepareServerResponse {
    /**
     helper class to process package receipt
     */
        public final InetAddress cliAddress;
        public final int cliPort;
        public final boolean success;

        public PrepareServerResponse(InetAddress cliAddress, int cliPort, boolean success) {
            this.cliAddress = cliAddress;
            this.cliPort = cliPort;
            this.success = success;
        }

        public InetAddress getCliAddress() {
            return cliAddress;
        }

        public int getCliPort() {
            return cliPort;
        }

        public boolean getSuccess() {
            return success;
    }
}
